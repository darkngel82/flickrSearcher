package com.dani.nv.flickrsearcher.constants

class Constants() {
    val flickrKey = "0df6713a45954861df41b7230de65355"
    val flickrSecret = "c8c3d4b3f44039b9"
}